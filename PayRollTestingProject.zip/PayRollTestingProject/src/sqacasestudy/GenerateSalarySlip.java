/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqacasestudy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 *
 * @author Admin
 */
public class GenerateSalarySlip {
    public static void main(String[] args) throws InterruptedException {
        
    
    WebDriver driver=new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost/PayrollEmp/AdminLogin.php");
        
        Thread.sleep(4000);
        driver.findElement(By.name("txtAname")).sendKeys("admin");
        driver.findElement(By.name("txtApass")).sendKeys("admin");
        driver.findElement(By.name("submit")).click();
        
        Thread.sleep(4000);
        driver.findElement(By.linkText("Generate-Salary-Slip")).click();
        Thread.sleep(1000);
        
        WebElement drop=driver.findElement(By.name("txtename1"));
        //c.selectByIndex(3);
        Select select=new Select(drop);
        select.selectByIndex(1);
        
        driver.findElement(By.name("find")).click();
        Thread.sleep(1000);
        WebElement month=driver.findElement(By.name("txtttldays"));
        Select monthDrop=new Select(month);
        monthDrop.selectByIndex(5);
        driver.findElement(By.name("elv")).sendKeys("3");
        
        driver.findElement(By.name("Gen")).click();
        
        Thread.sleep(4000);
        driver.quit();
        Thread.sleep(1000);
        
}
}