/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqacasestudy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 *
 * @author Admin
 */
public class ForWrngAdminLogin {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver=new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost/PayrollEmp/AdminLogin.php");
        
        Thread.sleep(1000);
        driver.findElement(By.name("txtAname")).sendKeys("Fazal");
        driver.findElement(By.name("txtApass")).sendKeys("fazal");
        driver.findElement(By.name("submit")).click();
        
        Thread.sleep(2002);
        driver.findElement(By.name("txtAname")).sendKeys("admin");
        driver.findElement(By.name("txtApass")).sendKeys("admin");
        driver.findElement(By.name("submit")).click();
        Thread.sleep(1000);
        driver.quit();
    }
}
